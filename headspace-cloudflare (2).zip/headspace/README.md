# Headspace · Sam's one-stop shop

Your Headspace app, ready to run on **Cloudflare** (free plan) with:

- **Cloud sync** between iPhone and laptop (Cloudflare D1 database)
- **A private login** so only your email gets in (Cloudflare Access)
- **Apple Health**: steps, sleep, active energy, resting heart rate and workouts, sent by the Health Auto Export iPhone app
- **Google Calendar**: today's schedule on My day, a live Calendar page, and 📅＋ to push dated tasks into your calendar
- **Google Drive**: pin files and folders to project cards
- **Milanote and any other link**: pin boards to project cards (Milanote has no public API, so links are the reliable option)
- **Add to Home Screen** on iPhone so it opens like an app

Allow about 45 minutes for the first setup. Steps 1 to 5 get you a private, syncing app. Steps 6 and 7 add Google and Apple Health, and you can do those later.

---

## What's in the folder

```
public/index.html          the app (works offline too; switches to cloud mode on your site)
public/manifest.webmanifest + icons   iPhone home screen icon
functions/api/...          your API (Cloudflare Pages Functions)
lib/util.js                shared helpers (login check, Google tokens)
schema.sql                 database tables
wrangler.toml              Cloudflare settings (you fill in 4 values)
```

## 1. Install the tools (once)

You need [Node.js](https://nodejs.org) (LTS). Then, in this folder:

```bash
npm install
npx wrangler login        # opens your browser to sign in to Cloudflare
```

## 2. Create the database

```bash
npx wrangler d1 create headspace
```

Copy the `database_id` it prints into `wrangler.toml`, replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`. Then create the tables:

```bash
npm run db:remote
```

## 3. Deploy

```bash
npx wrangler pages project create headspace --production-branch main
npm run deploy
```

You get an address like `https://headspace-abc.pages.dev`. **Don't use it yet.** Lock it down first (step 4). Until then the API refuses every request, so your data is safe, but the page itself is public.

## 4. Lock it to your email (Cloudflare Access, free)

1. Cloudflare dashboard → **Zero Trust** (first time: pick a team name and the Free plan). Your team domain is `https://<team-name>.cloudflareaccess.com`.
2. **Access → Applications → Add an application → Self-hosted.**
   - Name: `Headspace`
   - Domain: your Pages address, for example `headspace-abc.pages.dev` (or your own domain if you add one in step 8)
   - Policy: **Allow**, Include → **Emails** → your email
   - Login method: **One-time PIN** is simplest (you get a code by email). Google login also works.
3. Open the application's settings, copy the **Application Audience (AUD) Tag**.
4. A second application lets your iPhone send health data without a login screen:
   **Add an application → Self-hosted**, domain `headspace-abc.pages.dev`, path `api/health/ingest`, policy action **Bypass**, Include → **Everyone**. (That one address is protected by your own `HEALTH_TOKEN` instead.)
5. In `wrangler.toml`, fill in:
   ```toml
   ACCESS_TEAM_DOMAIN = "https://<team-name>.cloudflareaccess.com"
   ACCESS_AUD = "<the AUD tag>"
   ALLOWED_EMAIL = "<your email>"
   ```
6. `npm run deploy` again.

Open your address. You should see the Cloudflare sign-in, then Headspace. The sidebar should say **● Synced to your cloud**.

> **Bringing your existing data across:** in the old Headspace, click **Export backup** and copy the text. In the new one, click **Restore backup**, paste and confirm. It syncs up straight away.

## 5. Put it on your iPhone

Open your address in **Safari** → Share → **Add to Home Screen**. Sign in once. It now opens full screen with the bubble icon and syncs with your laptop.

---

## 6. Google Calendar and Drive (optional)

**In [Google Cloud Console](https://console.cloud.google.com):**

1. Create a project called `Headspace`.
2. **APIs & Services → Library**: enable **Google Calendar API**, **Google Drive API** and **Google Picker API**.
3. **OAuth consent screen**: External, app name `Headspace`, your email as support and developer contact. Add scopes `openid`, `email`, `.../auth/calendar.events`, `.../auth/drive.file`.
4. **Publish the app** (Audience → *Publish app* / *In production*). This matters: while it's in *Testing*, Google logs you out every 7 days. You'll see a "Google hasn't verified this app" screen when you connect. That's expected for a personal app: tap **Advanced → Go to Headspace**.
5. **Credentials → Create credentials → OAuth client ID → Web application**
   - Authorised JavaScript origin: `https://headspace-abc.pages.dev`
   - Authorised redirect URI: `https://headspace-abc.pages.dev/api/google/callback`
6. **Credentials → Create credentials → API key**. Restrict it to the **Google Picker API** and to the website `https://headspace-abc.pages.dev/*`.
7. Your **project number** (Dashboard / project settings) is the App ID.

**Then add the secrets** (each command asks you to paste the value):

```bash
npx wrangler pages secret put GOOGLE_CLIENT_ID --project-name headspace
npx wrangler pages secret put GOOGLE_CLIENT_SECRET --project-name headspace
npx wrangler pages secret put GOOGLE_API_KEY --project-name headspace
npx wrangler pages secret put GOOGLE_APP_ID --project-name headspace
npm run deploy
```

In Headspace: **Connections → Connect Google**.

Headspace asks only for `drive.file`, so it can see only the Drive files you pick in the picker, never your whole Drive.

## 7. Apple Health (optional)

1. Make a secret token and save it:
   ```bash
   openssl rand -hex 24        # copy the output
   npx wrangler pages secret put HEALTH_TOKEN --project-name headspace
   npm run deploy
   ```
2. On your iPhone, install **Health Auto Export (JSON+CSV)** (automations need its Premium tier).
3. **Automations → New automation → REST API**
   - URL: `https://headspace-abc.pages.dev/api/health/ingest` (also shown with a Copy button in Connections)
   - Headers: `Authorization` = `Bearer <your token>`
   - Export format **JSON**, Aggregate data **Days** (important: mixing hourly and daily exports would double count), Period **Since last sync**
   - Health metrics: Step Count, Active Energy, Sleep Analysis, Resting Heart Rate, Apple Exercise Time, optionally Heart Rate Variability, Mindful Minutes, Weight
   - Turn on **Workouts** too
4. Tap **Manual sync**. In Headspace, **My day** now shows "Your body today", and Connections shows the last update time.
5. Add the app's **Automations widget** to your Home Screen so it keeps syncing in the background. iOS only releases Health data while your phone is unlocked, so updates arrive as you use your phone, not live.

Set your step goal in Connections. When you hit it or log a workout, "Move your body" ticks itself.

---

## 8. Extras

- **Your own domain** (for example `headspace.yourdomain.co.uk`): Pages project → Custom domains. Then update the Access application domains and the Google origin and redirect URI to match.
- **Updating the app:** edit the files, then `npm run deploy`.
- **Run it on your computer:** `npm run db:local` once, then `npm run dev` and open http://localhost:8788. Locally there's no login (`.dev.vars` (copy it from `.dev.vars.example`) sets `DEV_NO_AUTH=1`) and the health token is `dev-health-token`.
- **Netlify:** this version uses Cloudflare's database and login, so it's Cloudflare-only. Cloudflare's free plan comfortably covers one person.

## API reference

All routes need your Cloudflare Access login except `/api/health/ingest`.

| Method | Route | What it does |
|---|---|---|
| GET | `/api/me` | Who you are, plus Google and Health connection status |
| POST | `/api/sync` | `{since, changes:[{collection,id,data|null}]}`. Saves your changes and returns everything changed since `since` |
| POST | `/api/health/ingest` | Health Auto Export webhook (`Authorization: Bearer HEALTH_TOKEN`) |
| GET | `/api/health/summary?days=7` | Daily steps, sleep, energy, resting HR, exercise, workouts |
| GET | `/api/google/auth` → `/api/google/callback` | Connect Google |
| GET | `/api/google/calendar?days=14` | Upcoming events from your primary calendar |
| POST | `/api/google/calendar` | `{title, date, time?, minutes?, detail?}`. Creates an event |
| GET | `/api/google/token` | Short-lived token for the Drive picker |
| POST | `/api/google/disconnect` | Revokes and forgets Google access |

Collections: `tasks`, `notes`, `projects`, `habits`, `journal`, `meta`. If the same item is edited on two devices before they sync, the last change saved wins.

## Security notes

- The API checks Cloudflare's signed login token on every request (not just the login screen) and only accepts `ALLOWED_EMAIL`.
- The health webhook accepts only requests carrying your `HEALTH_TOKEN`. Keep it secret. If it leaks, run `wrangler pages secret put HEALTH_TOKEN` with a new one and update the app.
- Google tokens are stored in your own D1 database, and "Disconnect" revokes them.
